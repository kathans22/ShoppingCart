<?php 
$unid = $_POST['unid'];

//echo $unid;

$conn = mysqli_connect("localhost","root","","shopcartdb") or die("connection failed"); 

$sql = "delete from carttb where username = '$unid'";

$result = mysqli_query($conn,$sql) or die("SQL Query Failed");

if($result)
{
	echo 1;
}
else
{
	echo 0;
}

?>