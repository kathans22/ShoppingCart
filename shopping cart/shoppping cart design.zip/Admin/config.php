<?php 

$conn = mysqli_connect("localhost","root","","shopcartdb") or die("connection failed");

?>